#pragma once
#include "netvar.h"

class CEntity
{
public:
	NETVAR(Spotted, "CBaseEntity->m_bSpotted", bool)
};
