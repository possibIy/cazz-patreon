﻿# 🛰 About
A very clean external, borderless ImGui project written as a YouTube tutorial.

## 🌠 Video
Make an ImGui cheat menu tutorial [video](https://www.youtube.com/watch?v=Nrta_J_c9Cc) here

## 🌌 Setup
- Clone the repo
- Customize menu to your liking
- Build in Release | x86
- Find your binary in the `Release` folder
- Enjoy

## 🗿 Disclaimer
I am not responsible for anything that happens when you use this software. Cheers.