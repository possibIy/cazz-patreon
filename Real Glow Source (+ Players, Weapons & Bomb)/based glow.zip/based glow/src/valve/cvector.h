#pragma once
#include <cstdint>

class CVector
{
public:
	float x{ }, y{ }, z{ };
};
