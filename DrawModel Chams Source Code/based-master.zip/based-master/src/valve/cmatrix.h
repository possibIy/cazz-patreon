#pragma once

class CMatrix3x4
{
public:
	float data[3][4];
};
