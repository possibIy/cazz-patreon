#pragma once

class CUserCmd;
namespace hacks
{
	void RunAimbot(CUserCmd* cmd) noexcept;
}
